<?php
require_once "config/database.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Supershop Management System</title>
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>

<h1>Welcome to Supershop Management System</h1>

<p>
    <a href="app/views/auth/login.php">Login</a> |
    <a href="app/views/auth/register.php">Register</a>
</p>

</body>
</html>
