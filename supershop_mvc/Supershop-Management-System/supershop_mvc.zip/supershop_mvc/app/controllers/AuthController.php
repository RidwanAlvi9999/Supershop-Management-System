<?php
require_once "../../config/database.php";

/* ========= LOGIN ========= */
if (isset($_POST['login'])) {

    $email    = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($user = mysqli_fetch_assoc($result)) {

        // PASSWORD CHECK
        if (password_verify($password, $user['password'])) {

            $_SESSION['user'] = $user;

            // ROLE BASED REDIRECT
            if ($user['role'] == "admin") {
                header("Location: /supershop_mvc/app/views/admin/dashboard.php");
            } elseif ($user['role'] == "employee") {
                header("Location: /supershop_mvc/app/views/employee/dashboard.php");
            } else {
                header("Location: /supershop_mvc/app/views/products/catalog.php");
            }

            exit;
        } else {
            echo "❌ Wrong password";
        }

    } else {
        echo "❌ User not found";
    }
}

/* ========= LOGOUT ========= */
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: /supershop_mvc/app/views/auth/login.php");
    exit;
}
