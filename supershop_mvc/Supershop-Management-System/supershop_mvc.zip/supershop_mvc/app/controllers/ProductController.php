<?php
require_once "../models/Product.php";
require_once "../../config/database.php";

if (isset($_POST['add_product'])) {

    $name  = $_POST['name'];
    $price = $_POST['price'];
    $qty   = $_POST['quantity'];
    $desc  = $_POST['description'];

    $img = $_FILES['image']['name'];
    $tmp = $_FILES['image']['tmp_name'];

    move_uploaded_file($tmp, "../../public/images/" . $img);

    Product::create($name, $price, $qty, $desc, $img);

    header("Location: /supershop_mvc/app/views/admin/manage_products.php");
    exit;
}

if (isset($_GET['delete'])) {

    Product::delete($_GET['delete']);

    header("Location: /supershop_mvc/app/views/admin/manage_products.php");
    exit;
}
