<?php
require_once "../../config/database.php";
require_once "../models/Product.php";

if(!isset($_SESSION['cart'])){
    $_SESSION['cart'] = [];
}

/* ADD TO CART (AJAX) */
if(isset($_POST['add'])){

    $id = $_POST['id'];

    if(isset($_SESSION['cart'][$id])){
        $_SESSION['cart'][$id]++;
    } else {
        $_SESSION['cart'][$id] = 1;
    }

    echo json_encode(["status"=>"success","cart"=>$_SESSION['cart']]);
}

/* REMOVE ITEM */
if(isset($_GET['remove'])){
    unset($_SESSION['cart'][$_GET['remove']]);
    header("Location: ../views/cart/view_cart.php");
}

/* CHECKOUT */
if(isset($_POST['checkout'])){
    $uid = $_SESSION['user']['id'];
    $total = 0;

    foreach($_SESSION['cart'] as $id=>$qty){
        $p = mysqli_fetch_assoc(Product::find($id));
        $total += $p['price'] * $qty;
    }

    mysqli_query($conn,"INSERT INTO orders(user_id,total,status) VALUES('$uid','$total','Pending')");
    $_SESSION['cart'] = [];

    header("Location: ../views/cart/view_cart.php?success=1");
}
