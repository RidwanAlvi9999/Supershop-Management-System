<?php
session_start();
require_once __DIR__ . "/../../config/database.php";

if(isset($_POST['update'])){
    $name=htmlspecialchars($_POST['name']);
    mysqli_query($conn,"UPDATE users SET name='$name' WHERE id=".$_SESSION['user']['id']);
    $_SESSION['user']['name']=$name;
    header("Location: ../views/auth/profile.php");
}

if(isset($_POST['change'])){
    $old=$_POST['old'];
    $new=password_hash($_POST['new'],PASSWORD_DEFAULT);

    $r=mysqli_query($conn,"SELECT password FROM users WHERE id=".$_SESSION['user']['id']);
    $u=mysqli_fetch_assoc($r);

    if(password_verify($old,$u['password'])){
        mysqli_query($conn,"UPDATE users SET password='$new' WHERE id=".$_SESSION['user']['id']);
    }

    header("Location: ../views/auth/profile.php");
}
