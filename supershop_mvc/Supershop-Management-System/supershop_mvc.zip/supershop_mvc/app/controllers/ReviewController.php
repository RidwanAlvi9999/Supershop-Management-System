<?php
session_start();
require_once __DIR__ . "/../models/Review.php";

if(isset($_POST['review'])){
    Review::add($_SESSION['user']['id'],$_POST['pid'],$_POST['rating'],htmlspecialchars($_POST['comment']));
    header("Location: ../views/products/details.php?id=".$_POST['pid']);
}
