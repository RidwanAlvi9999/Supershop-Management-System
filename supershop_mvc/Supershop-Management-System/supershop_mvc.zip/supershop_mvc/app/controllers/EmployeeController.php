<?php
session_start();
require_once __DIR__ . "/../models/Employee.php";


if(isset($_POST['assign'])){
    Employee::assignTask($_POST['emp'],$_POST['task']);
    header("Location: ../views/admin/employees.php");
}

if(isset($_POST['leave'])){
    Employee::applyLeave($_SESSION['user']['id'],$_POST['reason']);
    header("Location: ../views/employee/dashboard.php");
}

if(isset($_GET['approve'])){
    Employee::approveLeave($_GET['approve']);
    header("Location: ../views/admin/approve_leave.php");
}
