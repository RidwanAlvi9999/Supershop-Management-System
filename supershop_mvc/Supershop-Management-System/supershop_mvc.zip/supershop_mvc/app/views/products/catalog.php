<?php
require_once "../../../config/database.php";
require_once "../../models/Product.php";

$data = Product::all();
?>

<h1>Supershop Products</h1>

<?php while($p = mysqli_fetch_assoc($data)) { ?>

<div style="border:1px solid #ccc; margin:10px; padding:10px; display:inline-block;">
    <img src="../../../public/images/<?=$p['image']?>" width="150"><br>
    <b><?=$p['name']?></b><br>
    Price: <?=$p['price']?>৳<br><br>

    <!-- ✅ FIX 1: AJAX ADD TO CART BUTTON -->
    <button onclick="addToCart(<?=$p['id']?>)">Add to Cart</button>
</div>

<?php } ?>

<!-- ✅ FIX 2: LOAD CART JS -->
<script src="../../../public/js/cart.js"></script>

<br><br>
<a href="../cart/view_cart.php">🛒 View Cart</a>
<a href="details.php?id=<?=$p['id']?>">View</a>

