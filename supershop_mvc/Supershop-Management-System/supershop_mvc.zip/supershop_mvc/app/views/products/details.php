<?php
session_start();
require_once __DIR__ . "/../../../config/database.php";
require_once __DIR__ . "/../../models/Product.php";
require_once __DIR__ . "/../../models/Review.php";

$p = mysqli_fetch_assoc(Product::find($_GET['id']));
$reviews = Review::get($_GET['id']);
?>

<h2><?=$p['name']?></h2>
<img src="../../../public/images/<?=$p['image']?>" width="200"><br>
<?=$p['description']?><br><br>

<h3>Reviews</h3>

<?php while($r=mysqli_fetch_assoc($reviews)){ ?>
<p><b><?=$r['name']?></b>: <?=$r['comment']?> (<?=$r['rating']?>⭐)</p>
<?php } ?>

<h3>Add Review</h3>
<form method="POST" action="../../controllers/ReviewController.php">
<input type="hidden" name="pid" value="<?=$p['id']?>">
<select name="rating">
<option>1</option><option>2</option><option>3</option><option>4</option><option>5</option>
</select><br>
<textarea name="comment" required></textarea><br>
<button name="review">Submit</button>
</form>
