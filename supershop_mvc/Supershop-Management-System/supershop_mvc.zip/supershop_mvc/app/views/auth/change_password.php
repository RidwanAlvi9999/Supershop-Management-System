<h2>Change Password</h2>

<form method="POST" action="../../controllers/ProfileController.php">
<input type="password" name="old" placeholder="Old password" required><br><br>
<input type="password" name="new" placeholder="New password" required><br><br>
<button name="change">Change</button>
</form>
