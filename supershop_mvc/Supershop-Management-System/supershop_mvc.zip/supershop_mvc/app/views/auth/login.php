<!DOCTYPE html>
<html>
<head>
<title>Login</title>
<link rel="stylesheet" href="../../../public/css/style.css">
</head>
<body>

<h2>Login</h2>

<form method="POST" action="/supershop_mvc/app/controllers/AuthController.php">

    <input type="email" name="email" placeholder="Email" required><br><br>

    <input type="password" name="password" placeholder="Password" required><br><br>

    <button type="submit" name="login">Login</button>

</form>

<p><a href="register.php">Create new account</a></p>

</body>
</html>
