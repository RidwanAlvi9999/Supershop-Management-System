<?php require_once "../../../config/database.php"; ?>

<h2>My Profile</h2>

<form method="POST" action="../../controllers/ProfileController.php">
<input name="name" value="<?=$_SESSION['user']['name']?>" required><br><br>
<button name="update">Update</button>
</form>

<br><a href="change_password.php">Change Password</a>
