<!DOCTYPE html>
<html>
<head>
<title>Register</title>
<link rel="stylesheet" href="../../../public/css/style.css">
</head>
<body>

<h2>Register</h2>

<form method="POST" action="../../controllers/AuthController.php">

<input type="text" name="name" placeholder="Full Name" required><br><br>

<input type="email" name="email" placeholder="Email" required><br><br>

<input type="password" name="password" placeholder="Password" required><br><br>

<select name="role" required>
    <option value="">Select Role</option>
    <option value="admin">Admin</option>
    <option value="employee">Employee</option>
    <option value="customer">Customer</option>
</select><br><br>

<button type="submit" name="register">Register</button>

</form>

<p><a href="login.php">Already have account? Login</a></p>

</body>
</html>
