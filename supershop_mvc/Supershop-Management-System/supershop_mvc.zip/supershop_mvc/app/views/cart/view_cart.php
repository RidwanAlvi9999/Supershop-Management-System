<?php
require_once "../../../config/database.php";
require_once "../../models/Product.php";

$cart = $_SESSION['cart'] ?? [];
?>

<h1>My Cart</h1>
<a href="../products/catalog.php">← Continue Shopping</a><br><br>

<?php if(!$cart){ echo "<p>Cart is empty</p>"; } else { ?>

<table border="1" align="center">
<tr><th>Name</th><th>Price</th><th>Qty</th><th>Total</th><th>Action</th></tr>

<?php
$sum = 0;
foreach($cart as $id=>$qty){
$p = mysqli_fetch_assoc(Product::find($id));
$line = $p['price'] * $qty;
$sum += $line;
?>

<tr>
<td><?=$p['name']?></td>
<td><?=$p['price']?></td>
<td><?=$qty?></td>
<td><?=$line?></td>
<td><a href="../../controllers/CartController.php?remove=<?=$id?>">Remove</a></td>
</tr>

<?php } ?>

<tr><td colspan="3"><b>Grand Total</b></td><td><?=$sum?></td><td></td></tr>
</table>

<form method="POST" action="../../controllers/CartController.php">
<br><button name="checkout">Checkout</button>
</form>

<?php } ?>

<?php if(isset($_GET['success'])) echo "<p style='color:green'>Order placed successfully!</p>"; ?>
