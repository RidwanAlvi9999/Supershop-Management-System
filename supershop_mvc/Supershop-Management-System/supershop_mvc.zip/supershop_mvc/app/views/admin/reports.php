<?php require_once "../../../config/database.php"; ?>

<h2>System Reports</h2>

<p>Total Users: <?=mysqli_num_rows(mysqli_query($conn,"SELECT id FROM users"))?></p>
<p>Total Products: <?=mysqli_num_rows(mysqli_query($conn,"SELECT id FROM products"))?></p>
<p>Total Orders: <?=mysqli_num_rows(mysqli_query($conn,"SELECT id FROM orders"))?></p>
