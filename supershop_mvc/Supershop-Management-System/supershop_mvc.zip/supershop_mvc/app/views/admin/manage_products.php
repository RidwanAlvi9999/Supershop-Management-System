<?php
require_once "../../../config/database.php";
require_once "../../models/Product.php";

if ($_SESSION['user']['role'] != "admin") {
    header("Location: /supershop_mvc/app/views/auth/login.php");
    exit;
}

$data = Product::all();
?>

<h2>Manage Products</h2>
<a href="add_product.php">Add Product</a> | 
<a href="../../controllers/AuthController.php?logout=1">Logout</a>

<table border="1" align="center">
<tr>
<th>Name</th><th>Price</th><th>Qty</th><th>Image</th><th>Action</th>
</tr>

<?php while($p=mysqli_fetch_assoc($data)) { ?>
<tr>
<td><?=$p['name']?></td>
<td><?=$p['price']?></td>
<td><?=$p['quantity']?></td>
<td><img src="../../../public/images/<?=$p['image']?>" width="50"></td>
<td>
<a href="edit_product.php?id=<?=$p['id']?>">Edit</a> |
<a href="../../controllers/ProductController.php?delete=<?=$p['id']?>">Delete</a>
</td>
</tr>
<?php } ?>
</table>
