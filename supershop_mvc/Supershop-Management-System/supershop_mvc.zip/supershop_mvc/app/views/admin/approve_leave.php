<?php
require_once "../../../config/database.php";
require_once "../../models/Employee.php";
$data=Employee::allLeaves();
?>

<h2>Leave Requests</h2>

<table border="1" align="center">
<tr><th>Employee</th><th>Reason</th><th>Status</th><th>Action</th></tr>

<?php while($l=mysqli_fetch_assoc($data)){ ?>
<tr>
<td><?=$l['name']?></td>
<td><?=$l['reason']?></td>
<td><?=$l['status']?></td>
<td>
<a href="../../controllers/EmployeeController.php?approve=<?=$l['id']?>">Approve</a>
</td>
</tr>
<?php } ?>
</table>
