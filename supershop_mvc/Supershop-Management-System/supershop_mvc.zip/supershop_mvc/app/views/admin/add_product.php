<?php
require_once "../../../config/database.php";

if ($_SESSION['user']['role'] != "admin") {
    header("Location: /supershop_mvc/app/views/auth/login.php");
    exit;
}
?>

<h2>Add Product</h2>

<form method="POST"
      action="/supershop_mvc/app/controllers/ProductController.php"
      enctype="multipart/form-data">

    <input type="text" name="name" placeholder="Product Name" required><br><br>

    <input type="number" name="price" step="0.01" placeholder="Price" required><br><br>

    <input type="number" name="quantity" placeholder="Quantity" required><br><br>

    <textarea name="description" placeholder="Description"></textarea><br><br>

    <input type="file" name="image" required><br><br>

    <button type="submit" name="add_product">Save Product</button>

</form>

<br>
<a href="manage_products.php">⬅ Back</a>
