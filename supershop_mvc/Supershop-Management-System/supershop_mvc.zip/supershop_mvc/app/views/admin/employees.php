<?php
require_once "../../../config/database.php";
require_once "../../models/Employee.php";
$data=Employee::employees();
?>

<h2>Employees</h2>
<a href="approve_leave.php">Approve Leaves</a><br><br>

<table border="1" align="center">
<tr><th>Name</th><th>Email</th><th>Assign Task</th></tr>

<?php while($e=mysqli_fetch_assoc($data)){ ?>
<tr>
<td><?=$e['name']?></td>
<td><?=$e['email']?></td>
<td>
<form method="POST" action="../../controllers/EmployeeController.php">
<input type="hidden" name="emp" value="<?=$e['id']?>">
<input name="task" placeholder="Task" required>
<button name="assign">Assign</button>
</form>
</td>
</tr>
<?php } ?>
</table>
