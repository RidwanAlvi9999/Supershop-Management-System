<?php
session_start();
require_once "../../../config/database.php";

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== "admin") {
    header("Location: /supershop_mvc/app/views/auth/login.php");
    exit;
}
?>

<h1>Admin Dashboard</h1>

<p>Welcome, <?= $_SESSION['user']['name'] ?></p>

<ul>
    <li><a href="manage_products.php">Manage Products</a></li>

    <!-- ✅ EMPLOYEE SYSTEM -->
    <li><a href="employees.php">Manage Employees</a></li>
    <li><a href="approve_leave.php">Approve Leaves</a></li>

    <li><a href="/supershop_mvc/app/controllers/AuthController.php?logout=1">Logout</a></li>
</ul>
