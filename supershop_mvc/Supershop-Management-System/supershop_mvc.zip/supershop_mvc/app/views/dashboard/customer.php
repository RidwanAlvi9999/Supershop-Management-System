<?php
require_once "../../../config/database.php";
if(!isset($_SESSION['user']) || $_SESSION['user']['role']!="customer"){
    header("Location: ../../auth/login.php");
}
?>
<h1>Customer Dashboard</h1>
<p>Welcome, <?=$_SESSION['user']['name']?></p>
<a href="../../controllers/AuthController.php?logout=1">Logout</a>
