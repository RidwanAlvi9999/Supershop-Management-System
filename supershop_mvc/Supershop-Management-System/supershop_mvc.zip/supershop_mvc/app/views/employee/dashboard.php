<?php
require_once "../../../config/database.php";
require_once "../../models/Employee.php";

$tasks = Employee::myTasks($_SESSION['user']['id']);
?>

<h1>Employee Dashboard</h1>

<h3>My Tasks</h3>

<ul>
<?php while($t=mysqli_fetch_assoc($tasks)){ ?>
<li><?=$t['title']?> — <?=$t['status']?></li>
<?php } ?>
</ul>

<h3>Apply for Leave</h3>

<form method="POST" action="../../controllers/EmployeeController.php">
<textarea name="reason" required></textarea><br>
<button name="leave">Apply</button>
</form>

<br>
<a href="../../controllers/AuthController.php?logout=1">Logout</a>
