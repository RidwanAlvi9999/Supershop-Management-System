<?php
require_once __DIR__ . "/../../config/database.php";

class Review {

    public static function add($uid,$pid,$rate,$com){
        global $conn;
        $stmt=mysqli_prepare($conn,"INSERT INTO reviews(user_id,product_id,rating,comment) VALUES(?,?,?,?)");
        mysqli_stmt_bind_param($stmt,"iiis",$uid,$pid,$rate,$com);
        return mysqli_stmt_execute($stmt);
    }

    public static function get($pid){
        global $conn;
        $stmt=mysqli_prepare($conn,"SELECT users.name,reviews.* FROM reviews JOIN users ON reviews.user_id=users.id WHERE product_id=?");
        mysqli_stmt_bind_param($stmt,"i",$pid);
        mysqli_stmt_execute($stmt);
        return mysqli_stmt_get_result($stmt);
    }
}
