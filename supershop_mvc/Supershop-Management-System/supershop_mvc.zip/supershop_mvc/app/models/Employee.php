<?php
require_once __DIR__ . "/../../config/database.php";


class Employee {

    public static function employees(){
        global $conn;
        return mysqli_query($conn,"SELECT * FROM users WHERE role='employee'");
    }

    public static function assignTask($eid,$title){
        global $conn;
        $stmt=mysqli_prepare($conn,"INSERT INTO tasks(employee_id,title) VALUES(?,?)");
        mysqli_stmt_bind_param($stmt,"is",$eid,$title);
        return mysqli_stmt_execute($stmt);
    }

    public static function myTasks($id){
        global $conn;
        $stmt=mysqli_prepare($conn,"SELECT * FROM tasks WHERE employee_id=?");
        mysqli_stmt_bind_param($stmt,"i",$id);
        mysqli_stmt_execute($stmt);
        return mysqli_stmt_get_result($stmt);
    }

    public static function applyLeave($id,$reason){
        global $conn;
        $stmt=mysqli_prepare($conn,"INSERT INTO leaves(employee_id,reason) VALUES(?,?)");
        mysqli_stmt_bind_param($stmt,"is",$id,$reason);
        return mysqli_stmt_execute($stmt);
    }

    public static function allLeaves(){
        global $conn;
        return mysqli_query($conn,"SELECT leaves.*, users.name FROM leaves JOIN users ON leaves.employee_id=users.id");
    }

    public static function approveLeave($id){
        global $conn;
        mysqli_query($conn,"UPDATE leaves SET status='Approved' WHERE id=$id");
    }
}
