<?php
require_once "../../config/database.php";

class User {

    public static function register($name, $email, $password, $role) {
        global $conn;

        $hash = password_hash($password, PASSWORD_DEFAULT);

        $sql = "INSERT INTO users(name,email,password,role) VALUES (?,?,?,?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $name, $email, $hash, $role);

        return mysqli_stmt_execute($stmt);
    }

    public static function login($email) {
        global $conn;

        $sql = "SELECT * FROM users WHERE email=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);

        return mysqli_stmt_get_result($stmt);
    }
}
