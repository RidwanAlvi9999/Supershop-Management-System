<?php

class Product {

    public static function create($name,$price,$qty,$desc,$image){
        global $conn;
        $sql = "INSERT INTO products(name,price,quantity,description,image) VALUES(?,?,?,?,?)";
        $stmt = mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,"sdiss",$name,$price,$qty,$desc,$image);
        return mysqli_stmt_execute($stmt);
    }

    public static function all(){
        global $conn;
        return mysqli_query($conn,"SELECT * FROM products ORDER BY id DESC");
    }

    public static function find($id){
        global $conn;
        $sql="SELECT * FROM products WHERE id=?";
        $stmt=mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,"i",$id);
        mysqli_stmt_execute($stmt);
        return mysqli_stmt_get_result($stmt);
    }

    public static function update($id,$name,$price,$qty,$desc,$image){
        global $conn;
        $sql="UPDATE products SET name=?,price=?,quantity=?,description=?,image=? WHERE id=?";
        $stmt=mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,"sdissi",$name,$price,$qty,$desc,$image,$id);
        return mysqli_stmt_execute($stmt);
    }

    public static function delete($id){
        global $conn;
        $sql="DELETE FROM products WHERE id=?";
        $stmt=mysqli_prepare($conn,$sql);
        mysqli_stmt_bind_param($stmt,"i",$id);
        return mysqli_stmt_execute($stmt);
    }
}
