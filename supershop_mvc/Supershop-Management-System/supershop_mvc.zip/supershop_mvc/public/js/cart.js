function addToCart(id){
    fetch("../../controllers/CartController.php", {
        method:"POST",
        headers: {"Content-Type":"application/x-www-form-urlencoded"},
        body:"add=1&id="+id
    })
    .then(res=>res.json())
    .then(data=>{
        alert("Product added to cart!");
    });
}
